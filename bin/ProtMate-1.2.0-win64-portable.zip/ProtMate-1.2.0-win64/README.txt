ProtMate 1.2.0 - portable version for Windows (64-bit)
Laboratory formula calculator by Sanjeeva Wijeyesakere.
Copyright (C) 2024-2026 Sanjeeva Wijeyesakere
https://github.com/swijeyes/ProtMate

Requirements: Windows 10 or 11, x64. Nothing needs to be installed; the
folder can be kept anywhere, including on a USB stick.

  ProtMate.exe   Graphical version. Double-click to start.
  pmate.exe      Terminal version. Run it from Command Prompt, PowerShell or
                 Windows Terminal (double-clicking also opens it in a console
                 window). pmate.exe is self-contained and can be copied on its
                 own; ProtMate.exe needs everything else in this folder.

Keep the folder's layout as it is: ProtMate.exe loads the Qt DLLs next to it
and its plugins from the "platforms" and "styles" subfolders.

These programs are not code-signed, so Windows SmartScreen may warn the first
time they run ("More info" > "Run anyway").

Optional programs, found on PATH if installed:
  AutoDock Vina (vina.exe)  - "Run Vina" in both versions
  RasMol (rasmol.exe)       - "Open in RasMol" / the open command

Report files are written with Unix (LF) line endings, identical to the files
the macOS and Linux versions write.

The full user guide, the source code and an issue tracker for reporting
problems are at https://github.com/swijeyes/ProtMate.

License
  ProtMate is free software: you can redistribute it and/or modify it under
  the terms of the GNU General Public License as published by the Free
  Software Foundation, version 3. See LICENSE.txt for the full text. The
  source code for this version is available from
  https://github.com/swijeyes/ProtMate.

Disclaimer
  ProtMate is distributed in the hope that it will be useful, but WITHOUT ANY
  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE. The author assumes no liability for the accuracy
  of calculations or for the functionality of the program. Always verify
  results independently before relying on them. The body mass index
  calculator is not medical advice.

Third-party components
  Qt 6.11.2 (Qt6Core, Qt6Gui, Qt6Widgets and the plugins), (c) The Qt Company,
  used under the GNU LGPL version 3 (licenses/Qt-LGPL-3.0.txt, which
  incorporates licenses/Qt-GPL-3.0.txt). The DLLs are unmodified and can be
  replaced with other builds of Qt 6.11. Source code: https://download.qt.io/
  or https://code.qt.io/cgit/qt/qtbase.git (tag v6.11.2).

  libc++.dll and libunwind.dll from llvm-mingw 20231128 (LLVM 17.0.6), under
  the Apache License 2.0 with LLVM Exceptions (licenses/llvm-mingw-runtime.txt).
